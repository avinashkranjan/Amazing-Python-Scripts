from ninja import Form, NinjaAPI, File, Schema
from ninja.files import UploadedFile
from PyPDF4 import PdfFileReader,PdfFileWriter
import os
api=NinjaAPI()

class Inputfeild(Schema):
    page: int
    degree: int

@api.post("/upload")
def upload(request,details:Inputfeild = Form(...), file: UploadedFile = File(...)):
    
    
    data=file.read()
    target_file=file.name
    
    print(target_file)
        
    
    output_file=open('final.pdf','wb')
    
    pdf= PdfFileReader(target_file)
    writer=PdfFileWriter()
    page= pdf.getPage(details.page)
    page.rotateClockwise(details.degree)
    writer.addPage(page)
    writer.write(output_file)
    output_file.close()

    
    return {'input':file.name,'output_file': output_file}    